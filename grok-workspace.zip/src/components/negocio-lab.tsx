import { useEffect, useMemo, useState } from "react";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Copy, FlaskConical, Plus, Sparkles, Trash2 } from "lucide-react";
import {
  bestContributor,
  buildResults,
  convert,
  DAYS,
  formatInput,
  formatMoney,
  formatPercent,
  formatSigned,
  formatUnits,
  otherCurrency,
  parseAmount,
  PERIODS,
  periodById,
  projectPacks,
  sanitizeAmount,
  withUnitShift,
  type CalcSource,
  type Currency,
  type PeriodId,
  type PeriodPack,
  type PeriodResult,
  type Product,
} from "@/lib/sim";

const STORAGE_KEY = "camino-lab-v2";
const LEGACY_KEY = "camino-lab-v1";
const MAX_PRODUCTS = 12;

type SavedSim = {
  id: string;
  createdAt: number;
  label: string;
  shop: string;
  currency: Currency;
  rate: string;
  base: PeriodId;
  linked: boolean;
  other: string;
  products: Product[];
  byPeriod: Record<PeriodId, PeriodPack>;
  monthlyProfit: number;
};

type LabState = {
  shop: string;
  currency: Currency;
  rate: string;
  base: PeriodId;
  linked: boolean;
  other: string;
  products: Product[];
  byPeriod: Record<PeriodId, PeriodPack>;
  saved: SavedSim[];
};

type Basket = {
  id: string;
  label: string;
  base: PeriodId;
  currency: Currency;
  other: string;
  products: Array<Pick<Product, "name" | "units" | "cost" | "price">>;
};

const BASKETS: Basket[] = [
  {
    id: "ejemplo",
    label: "Ejemplo",
    base: "month",
    currency: "CUP",
    other: "300",
    products: [{ name: "Producto", units: "20", cost: "100", price: "150" }],
  },
  {
    id: "cafe",
    label: "Cafetería",
    base: "day",
    currency: "CUP",
    other: "350",
    products: [
      { name: "Café", units: "40", cost: "20", price: "50" },
      { name: "Pan", units: "18", cost: "25", price: "60" },
      { name: "Refresco", units: "12", cost: "40", price: "90" },
    ],
  },
  {
    id: "dulces",
    label: "Dulcería",
    base: "day",
    currency: "CUP",
    other: "220",
    products: [
      { name: "Brownie", units: "16", cost: "35", price: "90" },
      { name: "Galleta", units: "24", cost: "15", price: "40" },
      { name: "Flan", units: "8", cost: "30", price: "70" },
    ],
  },
  {
    id: "ropa",
    label: "Ropa",
    base: "week",
    currency: "CUP",
    other: "2500",
    products: [
      { name: "Camisa", units: "5", cost: "1500", price: "2800" },
      { name: "Pantalón", units: "3", cost: "2200", price: "4200" },
      { name: "Accesorio", units: "10", cost: "400", price: "900" },
    ],
  },
];

function makeProducts(rows: Basket["products"]): Product[] {
  return rows.map((row) => ({ ...row, id: crypto.randomUUID() }));
}

function freshState(basket: Basket = BASKETS[0]): LabState {
  const products = makeProducts(basket.products);
  return {
    shop: basket.id === "ejemplo" ? "" : basket.label,
    currency: basket.currency,
    rate: "400",
    base: basket.base,
    linked: true,
    other: basket.other,
    products,
    byPeriod: projectPacks(products, basket.other, basket.base),
    saved: [],
  };
}

function isCurrency(value: unknown): value is Currency {
  return value === "CUP" || value === "USD";
}

function isPeriod(value: unknown): value is PeriodId {
  return PERIODS.some((period) => period.id === value);
}

function isProduct(value: unknown): value is Product {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<Product>;
  return (
    typeof row.id === "string" &&
    typeof row.name === "string" &&
    typeof row.units === "string" &&
    typeof row.cost === "string" &&
    typeof row.price === "string"
  );
}

function isPack(value: unknown): value is PeriodPack {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<PeriodPack>;
  if (typeof row.other !== "string" || !row.units || typeof row.units !== "object") return false;
  return Object.values(row.units).every((units) => typeof units === "string");
}

function isPackMap(value: unknown): value is Record<PeriodId, PeriodPack> {
  if (!value || typeof value !== "object") return false;
  return PERIODS.every((period) => isPack((value as Record<string, unknown>)[period.id]));
}

function isSaved(value: unknown): value is SavedSim {
  if (!value || typeof value !== "object") return false;
  const row = value as Partial<SavedSim>;
  return (
    typeof row.id === "string" &&
    isCurrency(row.currency) &&
    typeof row.monthlyProfit === "number" &&
    isPeriod(row.base) &&
    Array.isArray(row.products) &&
    row.products.every(isProduct) &&
    typeof row.other === "string"
  );
}

function migrateLegacy(raw: string): LabState | null {
  try {
    const data = JSON.parse(raw) as {
      currency?: unknown;
      rate?: unknown;
      cost?: unknown;
      price?: unknown;
      base?: unknown;
      linked?: unknown;
      units?: unknown;
      other?: unknown;
      saved?: unknown;
    };
    if (!isCurrency(data.currency) || !isPeriod(data.base)) return null;
    if (typeof data.units !== "string" || typeof data.cost !== "string" || typeof data.price !== "string") return null;
    const other = typeof data.other === "string" ? data.other : "0";
    const products: Product[] = [
      { id: crypto.randomUUID(), name: "Producto", units: data.units, cost: data.cost, price: data.price },
    ];
    const base = freshState();
    return {
      ...base,
      currency: data.currency,
      rate: typeof data.rate === "string" ? data.rate : base.rate,
      base: data.base,
      linked: data.linked !== false,
      other,
      products,
      byPeriod: projectPacks(products, other, data.base),
      saved: [],
    };
  } catch {
    return null;
  }
}

function loadState(): LabState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw) as Partial<LabState>;
      if (!isCurrency(data.currency) || !isPeriod(data.base)) return null;
      if (!Array.isArray(data.products) || !data.products.every(isProduct)) return null;
      if (typeof data.other !== "string") return null;
      const base = freshState();
      const products = data.products.slice(0, MAX_PRODUCTS);
      return {
        ...base,
        shop: typeof data.shop === "string" ? data.shop.slice(0, 40) : "",
        currency: data.currency,
        rate: typeof data.rate === "string" ? data.rate : base.rate,
        base: data.base,
        linked: data.linked !== false,
        other: data.other,
        products,
        byPeriod: isPackMap(data.byPeriod) ? data.byPeriod : projectPacks(products, data.other, data.base),
        saved: Array.isArray(data.saved) ? data.saved.filter(isSaved).slice(0, 20) : [],
      };
    }
    const legacy = localStorage.getItem(LEGACY_KEY);
    return legacy ? migrateLegacy(legacy) : null;
  } catch {
    return null;
  }
}

function periodPhrase(id: PeriodId): string {
  if (id === "day") return "del día";
  if (id === "week") return "de la semana";
  if (id === "fortnight") return "de la quincena";
  return "del mes";
}

function insight(row: PeriodResult, currency: Currency): string {
  if (row.products.length === 0) return "Añade un producto con unidades, coste y precio para ver el resultado.";
  const losing = row.products.filter((product) => product.unitMargin < 0);
  if (losing.length === row.products.length) {
    return "Todos se venden por menos de lo que cuestan. Sube el precio o baja el coste antes de vender más.";
  }
  const best = bestContributor(row.products);
  const name = best?.name || "El mejor producto";
  if (row.contribution <= 0) {
    return "El catálogo no deja margen. Revisa el producto que se vende por debajo del coste.";
  }
  if (row.other > 0 && row.planToBreakEven != null && row.planToBreakEven > 1) {
    const covered = Math.round((row.contribution / row.other) * 100);
    return `Este plan cubre el ${covered} % de los otros gastos. ${name} es el que más aporta (${formatSigned(best?.contribution ?? 0, currency)}).`;
  }
  if (row.other > 0 && row.planToBreakEven != null) {
    return `Cubres los otros gastos con el ${Math.round(row.planToBreakEven * 100)} % de este plan. ${name} deja ${formatSigned(best?.contribution ?? 0, currency)}.`;
  }
  return `Sin otros gastos, la ganancia es el margen del catálogo: ${formatSigned(row.profit, currency)}.`;
}

function sourceOf(state: LabState): CalcSource {
  return {
    base: state.base,
    linked: state.linked,
    other: state.other,
    products: state.products,
    byPeriod: state.byPeriod,
  };
}

function Field({
  label,
  value,
  onChange,
  suffix,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  suffix: string;
}) {
  return (
    <label className="block min-w-0 rounded-card border border-line bg-surface px-5 py-4">
      <span className="block text-base font-medium text-muted">{label}</span>
      <span className="mt-2 flex min-w-0 items-end gap-3 border-b-2 border-gold pb-1">
        <input
          inputMode="decimal"
          enterKeyHint="done"
          size={6}
          value={value}
          onChange={(event) => onChange(sanitizeAmount(event.target.value))}
          className="w-0 min-w-0 flex-1 bg-transparent text-4xl font-semibold tracking-tight text-fg outline-none tabular-nums"
          placeholder="0"
        />
        <span className="mb-1 shrink-0 text-sm font-semibold text-gold">{suffix}</span>
      </span>
    </label>
  );
}

function MiniField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="min-w-0">
      <span className="block text-xs font-medium text-muted">{label}</span>
      <input
        inputMode="decimal"
        enterKeyHint="done"
        size={4}
        value={value}
        onChange={(event) => onChange(sanitizeAmount(event.target.value))}
        className="mt-1 w-full min-w-0 border-b border-gold bg-transparent py-1 text-xl font-semibold text-fg outline-none tabular-nums"
        placeholder="0"
      />
    </label>
  );
}

function MoneyLine({
  amount,
  currency,
  rate,
  signed = false,
  className,
}: {
  amount: number;
  currency: Currency;
  rate: number;
  signed?: boolean;
  className?: string;
}) {
  const fmt = signed ? formatSigned : formatMoney;
  const twin = otherCurrency(currency);
  return (
    <span className={className}>
      <span className="block tabular-nums">{fmt(amount, currency)}</span>
      {rate > 0 ? (
        <span className="mt-0.5 block text-xs font-medium text-muted tabular-nums">
          {fmt(convert(amount, currency, rate), twin)}
        </span>
      ) : null}
    </span>
  );
}

function Tip({
  active,
  payload,
  currency,
}: {
  active?: boolean;
  payload?: ReadonlyArray<{ value?: number | string }>;
  currency: Currency;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-line bg-bg px-3 py-2 text-sm font-medium text-fg tabular-nums">
      {formatSigned(Number(payload[0].value ?? 0), currency)}
    </div>
  );
}

function ProfitChart({ rows, currency }: { rows: PeriodResult[]; currency: Currency }) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) return <div className="h-44" />;
  const data = rows.map((row) => ({ name: row.short, ganancia: row.profit }));
  return (
    <div className="h-44 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}>
          <XAxis dataKey="name" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <YAxis hide />
          <Tooltip cursor={{ fill: "var(--color-surface-2)" }} content={<Tip currency={currency} />} />
          <Bar dataKey="ganancia" radius={[8, 8, 4, 4]} maxBarSize={48}>
            {data.map((row) => (
              <Cell key={row.name} fill={row.ganancia >= 0 ? "var(--color-gold)" : "var(--color-loss)"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function Row({ label, value, strong = false }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={"flex items-baseline justify-between gap-4 " + (strong ? "border-t border-line pt-3 text-base" : "")}>
      <dt className="text-muted">{label}</dt>
      <dd className={"text-right tabular-nums " + (strong ? "font-bold text-fg" : "font-semibold text-fg")}>{value}</dd>
    </div>
  );
}

export function NegocioLab() {
  const [state, setState] = useState<LabState>(() => freshState());
  const [ready, setReady] = useState(false);
  const [flash, setFlash] = useState(false);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    const stored = loadState();
    if (stored) setState(stored);
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state, ready]);

  const rate = parseAmount(state.rate);
  const results = useMemo(() => buildResults(sourceOf(state)), [state]);
  const selected = results.find((row) => row.id === state.base) ?? results[3];
  const month = results.find((row) => row.id === "month") ?? results[3];
  const period = periodById(state.base);
  const activeOther = state.linked ? state.other : (state.byPeriod[state.base]?.other ?? state.other);
  const best = bestContributor(selected.products);
  const positiveContribution = selected.products.reduce(
    (sum, product) => sum + Math.max(product.contribution, 0),
    0,
  );

  const shifts = [
    { id: "low", label: "−30 %", factor: -0.3 },
    { id: "plan", label: "Tu plan", factor: 0 },
    { id: "high", label: "+30 %", factor: 0.3 },
  ].map((shift) => ({ ...shift, row: withUnitShift(sourceOf(state), state.base, shift.factor) }));

  function patch(partial: Partial<LabState>) {
    setState((current) => ({ ...current, ...partial }));
  }

  function unitsOf(product: Product): string {
    if (state.linked) return product.units;
    return state.byPeriod[state.base]?.units?.[product.id] ?? product.units;
  }

  function updateProduct(id: string, partial: Partial<Product>) {
    setState((current) => {
      const products = current.products.map((product) => (product.id === id ? { ...product, ...partial } : product));
      if (partial.units == null || current.linked) {
        return { ...current, products };
      }
      const pack = current.byPeriod[current.base] ?? { other: current.other, units: {} };
      return {
        ...current,
        products,
        byPeriod: {
          ...current.byPeriod,
          [current.base]: { ...pack, units: { ...pack.units, [id]: partial.units } },
        },
      };
    });
  }

  function editOther(value: string) {
    setState((current) => {
      if (current.linked) return { ...current, other: value };
      const pack = current.byPeriod[current.base] ?? { other: value, units: {} };
      return {
        ...current,
        other: value,
        byPeriod: { ...current.byPeriod, [current.base]: { ...pack, other: value } },
      };
    });
  }

  function selectPeriod(next: PeriodId) {
    setState((current) => {
      if (next === current.base) return current;
      if (!current.linked) return { ...current, base: next };
      const factor = DAYS[next] / DAYS[current.base];
      const products = current.products.map((product) => ({
        ...product,
        units: formatInput(parseAmount(product.units) * factor),
      }));
      const other = formatInput(parseAmount(current.other) * factor);
      return { ...current, base: next, products, other, byPeriod: projectPacks(products, other, next) };
    });
  }

  function toggleLinked() {
    setState((current) => {
      if (current.linked) {
        return { ...current, linked: false, byPeriod: projectPacks(current.products, current.other, current.base) };
      }
      const pack = current.byPeriod[current.base];
      const products = current.products.map((product) => ({
        ...product,
        units: pack?.units?.[product.id] ?? product.units,
      }));
      const other = pack?.other ?? current.other;
      return { ...current, linked: true, products, other };
    });
  }

  function setCurrency(next: Currency) {
    setState((current) => {
      if (next === current.currency) return current;
      const fx = parseAmount(current.rate);
      const conv = (raw: string) => {
        if (!(fx > 0)) return raw;
        const amount = parseAmount(raw);
        return formatInput(current.currency === "CUP" ? amount / fx : amount * fx);
      };
      const products = current.products.map((product) => ({
        ...product,
        cost: conv(product.cost),
        price: conv(product.price),
      }));
      const byPeriod = {} as Record<PeriodId, PeriodPack>;
      for (const item of PERIODS) {
        const pack = current.byPeriod[item.id];
        byPeriod[item.id] = {
          other: conv(pack?.other ?? current.other),
          units: pack?.units ?? {},
        };
      }
      return { ...current, currency: next, products, other: conv(current.other), byPeriod };
    });
  }

  function applyBasket(id: string) {
    const basket = BASKETS.find((item) => item.id === id);
    if (!basket) return;
    const products = makeProducts(basket.products);
    setState((current) => ({
      ...current,
      shop: basket.label,
      currency: basket.currency,
      base: basket.base,
      linked: true,
      other: basket.other,
      products,
      byPeriod: projectPacks(products, basket.other, basket.base),
    }));
  }

  function addProduct() {
    setState((current) => {
      if (current.products.length >= MAX_PRODUCTS) return current;
      const product: Product = {
        id: crypto.randomUUID(),
        name: `Producto ${current.products.length + 1}`,
        units: "0",
        cost: "0",
        price: "0",
      };
      const products = [...current.products, product];
      const byPeriod = { ...current.byPeriod };
      for (const item of PERIODS) {
        const pack = byPeriod[item.id] ?? { other: current.other, units: {} };
        const factor = current.linked ? item.days / DAYS[current.base] : 1;
        byPeriod[item.id] = {
          ...pack,
          units: { ...pack.units, [product.id]: formatInput(parseAmount(product.units) * factor) },
        };
      }
      return { ...current, products, byPeriod };
    });
  }

  function duplicateProduct(id: string) {
    setState((current) => {
      if (current.products.length >= MAX_PRODUCTS) return current;
      const source = current.products.find((product) => product.id === id);
      if (!source) return current;
      const copy: Product = {
        ...source,
        id: crypto.randomUUID(),
        name: `${source.name || "Producto"} copia`.slice(0, 32),
      };
      const products = [...current.products, copy];
      const byPeriod = { ...current.byPeriod };
      for (const item of PERIODS) {
        const pack = byPeriod[item.id] ?? { other: current.other, units: {} };
        const units = current.linked
          ? formatInput(parseAmount(copy.units) * (item.days / DAYS[current.base]))
          : (pack.units[id] ?? copy.units);
        byPeriod[item.id] = { ...pack, units: { ...pack.units, [copy.id]: units } };
      }
      return { ...current, products, byPeriod };
    });
  }

  function removeProduct(id: string) {
    setState((current) => {
      const products = current.products.filter((product) => product.id !== id);
      const byPeriod = { ...current.byPeriod };
      for (const item of PERIODS) {
        const pack = byPeriod[item.id];
        if (!pack) continue;
        const units = { ...pack.units };
        delete units[id];
        byPeriod[item.id] = { ...pack, units };
      }
      return { ...current, products, byPeriod };
    });
  }

  function simular() {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    document.getElementById("comparar")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
    setFlash(true);
    window.setTimeout(() => setFlash(false), 700);
  }

  function registrar() {
    const stamp = new Date();
    const entry: SavedSim = {
      id: crypto.randomUUID(),
      createdAt: stamp.getTime(),
      label: state.shop.trim() || `Simulación ${state.saved.length + 1}`,
      shop: state.shop,
      currency: state.currency,
      rate: state.rate,
      base: state.base,
      linked: state.linked,
      other: state.other,
      products: state.products,
      byPeriod: state.linked ? projectPacks(state.products, state.other, state.base) : state.byPeriod,
      monthlyProfit: month.profit,
    };
    patch({ saved: [entry, ...state.saved].slice(0, 20) });
    setSavedFlash(true);
    window.setTimeout(() => setSavedFlash(false), 1400);
  }

  function restore(entry: SavedSim) {
    patch({
      shop: entry.shop,
      currency: entry.currency,
      rate: entry.rate || state.rate,
      base: entry.base,
      linked: entry.linked,
      other: entry.other,
      products: entry.products,
      byPeriod: isPackMap(entry.byPeriod) ? entry.byPeriod : projectPacks(entry.products, entry.other, entry.base),
    });
  }

  const total = state.saved.reduce((sum, entry) => {
    if (entry.currency === state.currency) return sum + entry.monthlyProfit;
    return sum + convert(entry.monthlyProfit, entry.currency, rate);
  }, 0);

  const mixParts = [
    { key: "coste", label: "Coste", value: Math.max(selected.cogs, 0), swatch: "bg-line" },
    { key: "otros", label: "Otros gastos", value: Math.max(selected.other, 0), swatch: "bg-muted" },
    { key: "gana", label: "Ganancia", value: Math.max(selected.profit, 0), swatch: "bg-gold" },
  ];
  const mixSum = mixParts.reduce((sum, part) => sum + part.value, 0);

  return (
    <main className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto w-full min-w-0 max-w-lg px-4 pt-6 pb-16 lg:max-w-5xl lg:px-8 lg:pt-10">
        <header className="mb-6">
          <p className="flex items-center gap-2 text-xs font-semibold tracking-widest text-gold">
            <Sparkles className="size-3.5" aria-hidden="true" />
            CAMINO A LA LIBERTAD
          </p>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-balance text-fg">Laboratorio de negocios</h1>
          <p className="mt-3 max-w-xl text-lg leading-relaxed text-pretty text-muted">
            Arma el catálogo, cambia precios y costes, y mira el día, la semana, la quincena y el mes en CUP y en USD.
          </p>
          <label className="mt-4 block">
            <span className="text-xs font-semibold tracking-wide text-muted uppercase">Nombre del negocio</span>
            <input
              value={state.shop}
              maxLength={40}
              placeholder="Mi negocio"
              aria-label="Nombre del negocio"
              onChange={(event) => patch({ shop: event.target.value.slice(0, 40) })}
              className="mt-1 w-full border-b border-line bg-transparent py-2 text-lg font-semibold text-fg outline-none"
            />
          </label>
          <div className="mt-4 flex flex-wrap gap-2">
            {BASKETS.map((basket) => (
              <button
                key={basket.id}
                type="button"
                onClick={() => applyBasket(basket.id)}
                className="rounded-full border border-line bg-surface px-3 py-2 text-sm font-semibold text-fg"
              >
                {basket.label}
              </button>
            ))}
          </div>
        </header>

        <div className="min-w-0 lg:grid lg:grid-cols-2 lg:items-start lg:gap-8">
          <section className="grid min-w-0 gap-3">
            <div className="flex w-full min-w-0 flex-col gap-3 rounded-card border border-line bg-bg-deep px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="grid w-full min-w-0 grid-cols-2 gap-1 rounded-full bg-surface p-1 sm:w-auto" role="group" aria-label="Moneda">
                {(["CUP", "USD"] as const).map((code) => (
                  <button
                    key={code}
                    type="button"
                    onClick={() => setCurrency(code)}
                    className={
                      "rounded-full px-4 py-2 text-sm font-semibold " +
                      (state.currency === code ? "bg-gold text-gold-ink" : "text-muted")
                    }
                    aria-pressed={state.currency === code}
                  >
                    {code}
                  </button>
                ))}
              </div>
              <label className="flex min-w-0 items-center gap-2 text-sm text-muted">
                <span className="shrink-0">1 USD =</span>
                <input
                  inputMode="decimal"
                  value={state.rate}
                  onChange={(event) => patch({ rate: sanitizeAmount(event.target.value) })}
                  className="w-20 border-b border-gold bg-transparent py-1 text-base font-semibold text-fg outline-none tabular-nums"
                  aria-label="Tasa en CUP por cada dólar"
                />
                <span>CUP</span>
              </label>
            </div>

            <div className="min-w-0">
              <div className="grid w-full min-w-0 grid-cols-4 gap-1 rounded-card bg-surface p-1" role="group" aria-label="Periodo">
                {PERIODS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectPeriod(item.id)}
                    className={
                      "min-w-0 rounded-xl px-0.5 py-3 text-xs font-semibold sm:text-sm " +
                      (state.base === item.id ? "bg-gold text-gold-ink" : "text-muted")
                    }
                    aria-pressed={state.base === item.id}
                  >
                    {item.chip}
                  </button>
                ))}
              </div>
              <div className="mt-3 flex min-w-0 items-center justify-between gap-3 px-1">
                <p className="min-w-0 flex-1 text-sm leading-snug text-muted">
                  {state.linked
                    ? `Las unidades son ${periodPhrase(state.base)}. Los demás periodos siguen el mismo ritmo.`
                    : `Estás anotando unidades y otros gastos ${periodPhrase(state.base)}.`}
                </p>
                <button
                  type="button"
                  role="switch"
                  aria-checked={state.linked}
                  aria-label="Mismo ritmo en todos los periodos"
                  onClick={toggleLinked}
                  className={"relative h-7 w-12 shrink-0 rounded-full " + (state.linked ? "bg-gold" : "bg-line")}
                >
                  <span
                    className={
                      "absolute top-0.5 size-6 rounded-full " + (state.linked ? "left-5 bg-gold-ink" : "left-0.5 bg-fg")
                    }
                  />
                </button>
              </div>
            </div>

            <div className="grid gap-3">
              <div className="flex items-end justify-between gap-3 px-1">
                <h2 className="text-xl font-bold">Productos</h2>
                <p className="text-sm text-muted tabular-nums">
                  {state.products.length}/{MAX_PRODUCTS}
                </p>
              </div>
              {state.products.length === 0 ? (
                <p className="rounded-card border border-line bg-surface px-5 py-4 text-sm leading-relaxed text-muted">
                  El catálogo está vacío. Añade un producto o carga Cafetería, Dulcería o Ropa.
                </p>
              ) : (
                state.products.map((product) => {
                  const math = selected.products.find((row) => row.id === product.id);
                  const share =
                    math && positiveContribution > 0 ? Math.max(math.contribution, 0) / positiveContribution : 0;
                  const healthy = (math?.unitMargin ?? 0) > 0;
                  return (
                    <article key={product.id} className="min-w-0 rounded-card border border-line bg-surface px-4 py-4">
                      <div className="flex min-w-0 items-start gap-2">
                        <input
                          value={product.name}
                          maxLength={32}
                          aria-label="Nombre del producto"
                          onChange={(event) => updateProduct(product.id, { name: event.target.value.slice(0, 32) })}
                          className="w-0 min-w-0 flex-1 bg-transparent text-lg font-semibold text-fg outline-none"
                          placeholder="Nombre"
                        />
                        <button
                          type="button"
                          aria-label={`Duplicar ${product.name || "producto"}`}
                          onClick={() => duplicateProduct(product.id)}
                          className="grid size-11 shrink-0 place-items-center rounded-full text-muted"
                        >
                          <Copy className="size-4" />
                        </button>
                        <button
                          type="button"
                          aria-label={`Quitar ${product.name || "producto"}`}
                          onClick={() => removeProduct(product.id)}
                          className="grid size-11 shrink-0 place-items-center rounded-full text-muted"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      </div>
                      <div className="mt-3 grid grid-cols-3 gap-3">
                        <MiniField
                          label="Unidades"
                          value={unitsOf(product)}
                          onChange={(value) => updateProduct(product.id, { units: value })}
                        />
                        <MiniField
                          label={`Coste ${state.currency}`}
                          value={product.cost}
                          onChange={(value) => updateProduct(product.id, { cost: value })}
                        />
                        <MiniField
                          label={`Precio ${state.currency}`}
                          value={product.price}
                          onChange={(value) => updateProduct(product.id, { price: value })}
                        />
                      </div>
                      <div className="mt-3 flex items-center justify-between gap-3 text-sm">
                        <span className={healthy ? "font-semibold text-gain" : "font-semibold text-loss"}>
                          {formatSigned(math?.unitMargin ?? 0, state.currency)} / ud
                        </span>
                        <span className={"font-bold tabular-nums " + ((math?.contribution ?? 0) >= 0 ? "text-gain" : "text-loss")}>
                          {formatSigned(math?.contribution ?? 0, state.currency)}
                        </span>
                      </div>
                      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-bg">
                        <div className="h-full bg-gold" style={{ width: `${share * 100}%` }} />
                      </div>
                      {best?.id === product.id ? (
                        <p className="mt-2 text-xs font-semibold tracking-wide text-gold uppercase">El que más deja</p>
                      ) : null}
                    </article>
                  );
                })
              )}
              <button
                type="button"
                onClick={addProduct}
                disabled={state.products.length >= MAX_PRODUCTS}
                className="flex w-full items-center justify-center gap-2 rounded-card border border-gold px-4 py-3 text-base font-semibold text-gold disabled:opacity-40"
              >
                <Plus className="size-5" aria-hidden="true" />
                Añadir producto
              </button>
            </div>

            <Field
              label={`Otros gastos del negocio (${state.currency})`}
              value={activeOther}
              onChange={editOther}
              suffix={period.short}
            />

            <button
              type="button"
              onClick={simular}
              className="flex w-full min-w-0 items-center justify-center gap-2 rounded-xl bg-gold px-4 py-4 text-lg font-bold text-gold-ink"
            >
              <FlaskConical className="size-5" aria-hidden="true" />
              Simular el negocio
            </button>
            <button
              type="button"
              onClick={registrar}
              className="w-full min-w-0 rounded-card border border-line bg-surface px-4 py-4 text-center text-base font-semibold leading-snug text-balance text-fg"
            >
              {savedFlash
                ? "Guardado en activos"
                : `Registrar ${formatSigned(month.profit, state.currency)}/mes simulado en activos`}
            </button>
          </section>

          <section
            id="comparar"
            className={"mt-8 grid min-w-0 scroll-mt-6 gap-3 lg:mt-0 " + (flash ? "rounded-card ring-2 ring-gold" : "")}
          >
            <div className="px-1">
              <h2 className="text-xl font-bold">Comparar periodos</h2>
              <p className="mt-1 text-sm text-muted">
                {state.shop.trim() || "Tu negocio"} · {state.products.length}{" "}
                {state.products.length === 1 ? "producto" : "productos"} · {state.currency} y {otherCurrency(state.currency)}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {results.map((row) => {
                const positive = row.profit >= 0;
                const active = row.id === state.base;
                return (
                  <button
                    key={row.id}
                    type="button"
                    onClick={() => selectPeriod(row.id)}
                    className={
                      "min-w-0 rounded-card border px-3 py-3 text-left " +
                      (active ? "border-gold bg-surface-2" : "border-line bg-surface")
                    }
                  >
                    <span className="text-xs font-semibold tracking-wide text-muted uppercase">{row.label}</span>
                    <span className={"mt-1 block text-xl font-bold tabular-nums " + (positive ? "text-gain" : "text-loss")}>
                      {formatSigned(row.profit, state.currency)}
                    </span>
                    {rate > 0 ? (
                      <span className="mt-0.5 block text-xs text-muted tabular-nums">
                        {formatSigned(convert(row.profit, state.currency, rate), otherCurrency(state.currency))}
                      </span>
                    ) : null}
                    <span className="mt-2 block text-xs text-muted tabular-nums">{formatUnits(row.units)} uds</span>
                  </button>
                );
              })}
            </div>

            <article className="rounded-card border border-line bg-surface px-5 py-5" aria-live="polite">
              <p className="text-sm font-semibold tracking-wide text-gold uppercase">{selected.label}</p>
              <MoneyLine
                amount={selected.profit}
                currency={state.currency}
                rate={rate}
                signed
                className={"mt-2 text-4xl font-extrabold " + (selected.profit >= 0 ? "text-gain" : "text-loss")}
              />
              <p className="mt-3 text-sm leading-relaxed text-pretty text-muted">{insight(selected, state.currency)}</p>
              <dl className="mt-5 grid gap-3 text-sm">
                <Row label="Ingresos" value={formatMoney(selected.revenue, state.currency)} />
                <Row label="Coste de productos" value={formatMoney(-selected.cogs, state.currency)} />
                <Row label="Margen antes de otros" value={formatSigned(selected.contribution, state.currency)} />
                <Row label="Otros gastos" value={formatMoney(-selected.other, state.currency)} />
                <Row label="Ganancia" value={formatSigned(selected.profit, state.currency)} strong />
                <Row label="Margen final" value={formatPercent(selected.margin)} />
                <Row
                  label="Plan para no perder"
                  value={selected.planToBreakEven == null ? "No alcanza" : formatPercent(selected.planToBreakEven)}
                />
              </dl>
              {mixSum > 0 ? (
                <div className="mt-5">
                  <div className="flex h-3 overflow-hidden rounded-full bg-bg">
                    {mixParts.map((part) => (
                      <div key={part.key} className={part.swatch} style={{ width: `${(part.value / mixSum) * 100}%` }} />
                    ))}
                  </div>
                  <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
                    {mixParts.map((part) => (
                      <li key={part.key} className="flex items-center gap-1.5">
                        <span className={"size-2 rounded-full " + part.swatch} />
                        {part.label}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </article>

            {selected.products.length > 0 ? (
              <article className="rounded-card border border-line bg-surface px-5 py-5">
                <h3 className="text-base font-bold">Aporte de cada producto</h3>
                <p className="mt-1 text-sm text-muted">Margen de las ventas {periodPhrase(state.base)}, antes de otros gastos.</p>
                <ul className="mt-4 grid gap-3">
                  {selected.products.map((product) => (
                    <li key={product.id} className="min-w-0">
                      <div className="flex items-baseline justify-between gap-3">
                        <span className="truncate font-semibold">{product.name || "Sin nombre"}</span>
                        <span className={"shrink-0 text-sm font-bold tabular-nums " + (product.contribution >= 0 ? "text-gain" : "text-loss")}>
                          {formatSigned(product.contribution, state.currency)}
                        </span>
                      </div>
                      <p className="mt-0.5 text-xs text-muted tabular-nums">
                        {formatUnits(product.units)} uds · {formatSigned(product.unitMargin, state.currency)} / ud · margen{" "}
                        {formatPercent(product.margin)}
                      </p>
                    </li>
                  ))}
                </ul>
              </article>
            ) : null}

            <article className="rounded-card border border-line bg-surface px-5 py-5">
              <h3 className="text-base font-bold">Si vendes más o menos</h3>
              <p className="mt-1 text-sm text-muted">
                Cambia todas las unidades {periodPhrase(state.base)}. Los otros gastos se quedan quietos.
              </p>
              <div className="mt-4 grid grid-cols-3 gap-2">
                {shifts.map((shift) => (
                  <div key={shift.id} className="min-w-0 rounded-xl bg-bg px-2 py-3 text-center">
                    <p className="text-xs font-semibold text-muted">{shift.label}</p>
                    <p className={"mt-1 text-sm font-bold tabular-nums " + (shift.row.profit >= 0 ? "text-gain" : "text-loss")}>
                      {formatSigned(shift.row.profit, state.currency)}
                    </p>
                    <p className="mt-1 text-xs text-muted tabular-nums">{formatUnits(shift.row.units)} uds</p>
                  </div>
                ))}
              </div>
            </article>

            <article className="min-w-0 rounded-card border border-line bg-surface px-4 py-4">
              <h3 className="px-1 text-base font-bold">Ganancia según el periodo</h3>
              <ProfitChart rows={results} currency={state.currency} />
            </article>
          </section>
        </div>

        <section className="mt-8 rounded-card border border-line bg-surface px-5 py-5">
          <div className="flex items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-bold">Activos simulados</h2>
              <p className="mt-1 text-sm text-muted">La suma mensual de lo que guardaste. No es dinero real.</p>
            </div>
            <p className={"text-right text-lg font-bold tabular-nums " + (total >= 0 ? "text-gain" : "text-loss")}>
              {formatSigned(total, state.currency)}
              <span className="block text-xs font-medium text-muted">al mes</span>
            </p>
          </div>
          {state.saved.length === 0 ? (
            <p className="mt-4 text-sm leading-relaxed text-muted">
              Todavía no hay simulaciones guardadas. Cuando un catálogo te convenza, regístralo arriba.
            </p>
          ) : (
            <ul className="mt-2">
              {state.saved.map((entry) => (
                <li key={entry.id} className="flex items-center gap-2 border-b border-line py-3 last:border-b-0">
                  <button type="button" onClick={() => restore(entry)} className="min-w-0 flex-1 text-left">
                    <span className="block truncate font-semibold">{entry.label}</span>
                    <span className="mt-0.5 block text-xs text-muted">
                      {new Date(entry.createdAt).toLocaleDateString("es", { day: "numeric", month: "short" })}
                      {" · "}
                      {entry.products.length} {entry.products.length === 1 ? "producto" : "productos"}
                      {" · "}
                      {periodById(entry.base).label}
                      {" · "}
                      {entry.currency}
                    </span>
                  </button>
                  <span className={"shrink-0 text-sm font-bold tabular-nums " + (entry.monthlyProfit >= 0 ? "text-gain" : "text-loss")}>
                    {formatSigned(entry.monthlyProfit, entry.currency)}
                  </span>
                  <button
                    type="button"
                    aria-label={`Quitar ${entry.label}`}
                    onClick={() => patch({ saved: state.saved.filter((item) => item.id !== entry.id) })}
                    className="grid size-11 shrink-0 place-items-center rounded-full text-muted"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        <p className="mt-6 text-center text-xs leading-relaxed text-muted">
          Mes de 30 días, quincena de 15 y semana de 7. Los CUP se redondean al peso. La tasa la pones tú: no es un cambio oficial.
        </p>
      </div>
    </main>
  );
}
