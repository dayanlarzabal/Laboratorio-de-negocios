export const PERIODS = [
  { id: "day", label: "Día", chip: "Día", short: "Día", days: 1 },
  { id: "week", label: "Semana", chip: "Semanal", short: "Semana", days: 7 },
  { id: "fortnight", label: "Quincena", chip: "Quincenal", short: "Quincena", days: 15 },
  { id: "month", label: "Mes", chip: "Mensual", short: "Mes", days: 30 },
] as const;

export type PeriodId = (typeof PERIODS)[number]["id"];
export type Currency = "CUP" | "USD";

export const DAYS: Record<PeriodId, number> = {
  day: 1,
  week: 7,
  fortnight: 15,
  month: 30,
};

export type Product = {
  id: string;
  name: string;
  units: string;
  cost: string;
  price: string;
};

export type PeriodPack = {
  other: string;
  units: Record<string, string>;
};

export type ProductMath = {
  id: string;
  name: string;
  units: number;
  cost: number;
  price: number;
  revenue: number;
  cogs: number;
  contribution: number;
  unitMargin: number;
  margin: number | null;
};

export type PeriodResult = {
  id: PeriodId;
  label: string;
  short: string;
  days: number;
  units: number;
  other: number;
  revenue: number;
  cogs: number;
  contribution: number;
  profit: number;
  margin: number | null;
  planToBreakEven: number | null;
  products: ProductMath[];
};

export type CalcSource = {
  base: PeriodId;
  linked: boolean;
  other: string;
  products: Product[];
  byPeriod: Record<PeriodId, PeriodPack>;
};

export function parseAmount(raw: string): number {
  const cleaned = raw.trim().replace(/\s/g, "").replace(",", ".");
  if (!cleaned || cleaned === ".") return 0;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}

export function sanitizeAmount(raw: string): string {
  const cleaned = raw.replace(/[^\d.,]/g, "");
  const sep = cleaned.search(/[.,]/);
  if (sep === -1) return cleaned.slice(0, 9);
  const head = cleaned.slice(0, sep).slice(0, 9);
  const tail = cleaned
    .slice(sep + 1)
    .replace(/[.,]/g, "")
    .slice(0, 2);
  return `${head}${cleaned[sep]}${tail}`;
}

export function formatInput(n: number): string {
  if (!Number.isFinite(n)) return "0";
  const rounded = Math.round(n * 100) / 100;
  if (rounded === 0) return "0";
  return String(rounded);
}

export function formatNumber(value: number, digits: number): string {
  const negative = value < 0;
  const abs = Math.abs(value);
  const [int, frac] = abs.toFixed(digits).split(".");
  const withSep = int.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const body = digits > 0 ? `${withSep},${frac}` : withSep;
  return negative ? `−${body}` : body;
}

export function formatMoney(value: number, currency: Currency): string {
  const digits = currency === "USD" ? 2 : 0;
  const rounded = currency === "USD" ? Math.round(value * 100) / 100 : Math.round(value);
  return `${formatNumber(rounded, digits)} ${currency}`;
}

export function formatSigned(value: number, currency: Currency): string {
  const digits = currency === "USD" ? 2 : 0;
  const rounded = currency === "USD" ? Math.round(value * 100) / 100 : Math.round(value);
  const body = `${formatNumber(Math.abs(rounded), digits)} ${currency}`;
  if (rounded > 0) return `+${body}`;
  if (rounded < 0) return `−${body}`;
  return body;
}

export function formatUnits(n: number): string {
  const rounded = Math.round(n * 10) / 10;
  if (Math.abs(rounded - Math.round(rounded)) < 0.05) return formatNumber(Math.round(rounded), 0);
  return formatNumber(rounded, 1);
}

export function formatPercent(ratio: number | null): string {
  if (ratio == null || !Number.isFinite(ratio)) return "—";
  return `${Math.round(ratio * 100)} %`;
}

export function convert(amount: number, from: Currency, rate: number): number {
  if (!(rate > 0) || !Number.isFinite(amount)) return 0;
  return from === "CUP" ? amount / rate : amount * rate;
}

export function otherCurrency(currency: Currency): Currency {
  return currency === "CUP" ? "USD" : "CUP";
}

export function periodById(id: PeriodId) {
  return PERIODS.find((p) => p.id === id) ?? PERIODS[0];
}

export function projectPacks(
  products: Product[],
  other: string,
  base: PeriodId,
): Record<PeriodId, PeriodPack> {
  const map = {} as Record<PeriodId, PeriodPack>;
  for (const period of PERIODS) {
    const factor = period.days / DAYS[base];
    const units: Record<string, string> = {};
    for (const product of products) {
      units[product.id] = formatInput(parseAmount(product.units) * factor);
    }
    map[period.id] = { other: formatInput(parseAmount(other) * factor), units };
  }
  return map;
}

function mathFor(product: Product, units: number): ProductMath {
  const cost = parseAmount(product.cost);
  const price = parseAmount(product.price);
  const revenue = units * price;
  const cogs = units * cost;
  const contribution = revenue - cogs;
  return {
    id: product.id,
    name: product.name.trim(),
    units,
    cost,
    price,
    revenue,
    cogs,
    contribution,
    unitMargin: price - cost,
    margin: revenue > 0 ? contribution / revenue : null,
  };
}

function rowFor(source: CalcSource, id: PeriodId, unitFactor = 1): PeriodResult {
  const period = periodById(id);
  const scale = period.days / DAYS[source.base];
  const pack = source.byPeriod[id];
  const products = source.products.map((product) => {
    const baseUnits = source.linked
      ? parseAmount(product.units) * scale
      : parseAmount(pack?.units?.[product.id] ?? "0");
    return mathFor(product, baseUnits * unitFactor);
  });
  const other = source.linked ? parseAmount(source.other) * scale : parseAmount(pack?.other ?? "0");
  const units = products.reduce((sum, product) => sum + product.units, 0);
  const revenue = products.reduce((sum, product) => sum + product.revenue, 0);
  const cogs = products.reduce((sum, product) => sum + product.cogs, 0);
  const contribution = products.reduce((sum, product) => sum + product.contribution, 0);
  const profit = contribution - other;
  return {
    id,
    label: period.label,
    short: period.short,
    days: period.days,
    units,
    other,
    revenue,
    cogs,
    contribution,
    profit,
    margin: revenue > 0 ? profit / revenue : null,
    planToBreakEven: contribution > 0 ? other / contribution : null,
    products,
  };
}

export function buildResults(source: CalcSource): PeriodResult[] {
  return PERIODS.map((period) => rowFor(source, period.id));
}

export function withUnitShift(source: CalcSource, id: PeriodId, factor: number): PeriodResult {
  return rowFor(source, id, 1 + factor);
}

export function bestContributor(products: ProductMath[]): ProductMath | null {
  const ranked = products.filter((product) => product.contribution > 0);
  if (!ranked.length) return null;
  return ranked.reduce((best, product) => (product.contribution > best.contribution ? product : best));
}
