import { createFileRoute } from "@tanstack/react-router";
import { NegocioLab } from "@/components/negocio-lab";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NegocioLab />;
}
