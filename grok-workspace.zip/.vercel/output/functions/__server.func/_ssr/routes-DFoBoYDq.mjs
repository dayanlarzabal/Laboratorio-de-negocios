import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as FlaskConical, n as Trash2, r as Sparkles } from "../_libs/lucide-react.mjs";
import { a as Cell, i as Bar, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DFoBoYDq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PERIODS = [
	{
		id: "day",
		label: "Día",
		chip: "Día",
		short: "Día",
		days: 1
	},
	{
		id: "week",
		label: "Semana",
		chip: "Semanal",
		short: "Semana",
		days: 7
	},
	{
		id: "fortnight",
		label: "Quincena",
		chip: "Quincenal",
		short: "Quincena",
		days: 15
	},
	{
		id: "month",
		label: "Mes",
		chip: "Mensual",
		short: "Mes",
		days: 30
	}
];
var DAYS = {
	day: 1,
	week: 7,
	fortnight: 15,
	month: 30
};
function parseAmount(raw) {
	const cleaned = raw.trim().replace(/\s/g, "").replace(",", ".");
	if (!cleaned || cleaned === ".") return 0;
	const n = Number(cleaned);
	return Number.isFinite(n) ? n : 0;
}
function sanitizeAmount(raw) {
	const cleaned = raw.replace(/[^\d.,]/g, "");
	const sep = cleaned.search(/[.,]/);
	if (sep === -1) return cleaned.slice(0, 9);
	const head = cleaned.slice(0, sep).slice(0, 9);
	const tail = cleaned.slice(sep + 1).replace(/[.,]/g, "").slice(0, 2);
	return `${head}${cleaned[sep]}${tail}`;
}
function formatInput(n) {
	if (!Number.isFinite(n)) return "0";
	const rounded = Math.round(n * 100) / 100;
	if (rounded === 0) return "0";
	return String(rounded);
}
function formatNumber(value, digits) {
	const negative = value < 0;
	const [int, frac] = Math.abs(value).toFixed(digits).split(".");
	const withSep = int.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	const body = digits > 0 ? `${withSep},${frac}` : withSep;
	return negative ? `−${body}` : body;
}
function formatMoney(value, currency) {
	const digits = currency === "USD" ? 2 : 0;
	return `${formatNumber(currency === "USD" ? Math.round(value * 100) / 100 : Math.round(value), digits)} ${currency}`;
}
function formatSigned(value, currency) {
	const digits = currency === "USD" ? 2 : 0;
	const rounded = currency === "USD" ? Math.round(value * 100) / 100 : Math.round(value);
	const body = `${formatNumber(Math.abs(rounded), digits)} ${currency}`;
	if (rounded > 0) return `+${body}`;
	if (rounded < 0) return `−${body}`;
	return body;
}
function formatUnits(n) {
	const rounded = Math.round(n * 10) / 10;
	if (Math.abs(rounded - Math.round(rounded)) < .05) return formatNumber(Math.round(rounded), 0);
	return formatNumber(rounded, 1);
}
function formatPercent(ratio) {
	if (ratio == null || !Number.isFinite(ratio)) return "—";
	return `${Math.round(ratio * 100)} %`;
}
function convert(amount, from, rate) {
	if (!(rate > 0) || !Number.isFinite(amount)) return 0;
	return from === "CUP" ? amount / rate : amount * rate;
}
function otherCurrency(currency) {
	return currency === "CUP" ? "USD" : "CUP";
}
function periodById(id) {
	return PERIODS.find((p) => p.id === id) ?? PERIODS[0];
}
function projectFields(units, other, base) {
	const u = parseAmount(units);
	const o = parseAmount(other);
	const map = {};
	for (const period of PERIODS) {
		const factor = period.days / DAYS[base];
		map[period.id] = {
			units: formatInput(u * factor),
			other: formatInput(o * factor)
		};
	}
	return map;
}
function rowFor(source, id, unitFactor = 1) {
	const period = periodById(id);
	const unitsRaw = source.linked ? parseAmount(source.units) * (period.days / DAYS[source.base]) : parseAmount(source.byPeriod[id].units);
	const other = source.linked ? parseAmount(source.other) * (period.days / DAYS[source.base]) : parseAmount(source.byPeriod[id].other);
	const units = unitsRaw * unitFactor;
	const price = parseAmount(source.price);
	const cost = parseAmount(source.cost);
	const revenue = units * price;
	const cogs = units * cost;
	const profit = revenue - cogs - other;
	const unitMargin = price - cost;
	return {
		id,
		label: period.label,
		short: period.short,
		days: period.days,
		units,
		other,
		revenue,
		cogs,
		profit,
		margin: revenue > 0 ? profit / revenue : null,
		unitMargin,
		breakEvenUnits: unitMargin > 0 ? other / unitMargin : null
	};
}
function buildResults(source) {
	return PERIODS.map((period) => rowFor(source, period.id));
}
function withUnitShift(source, id, factor) {
	return rowFor(source, id, 1 + factor);
}
var STORAGE_KEY = "camino-lab-v1";
var PRESETS = [
	{
		id: "ejemplo",
		label: "Ejemplo",
		units: "20",
		cost: "100",
		price: "150",
		other: "300",
		base: "month",
		currency: "CUP"
	},
	{
		id: "cafe",
		label: "Café",
		units: "40",
		cost: "20",
		price: "50",
		other: "250",
		base: "day",
		currency: "CUP"
	},
	{
		id: "dulces",
		label: "Dulces",
		units: "25",
		cost: "35",
		price: "80",
		other: "200",
		base: "day",
		currency: "CUP"
	},
	{
		id: "ropa",
		label: "Ropa",
		units: "8",
		cost: "1500",
		price: "2800",
		other: "2000",
		base: "week",
		currency: "CUP"
	}
];
function defaultState() {
	const preset = PRESETS[0];
	return {
		currency: preset.currency,
		rate: "400",
		cost: preset.cost,
		price: preset.price,
		base: preset.base,
		linked: true,
		units: preset.units,
		other: preset.other,
		byPeriod: projectFields(preset.units, preset.other, preset.base),
		saved: []
	};
}
function isCurrency(value) {
	return value === "CUP" || value === "USD";
}
function isPeriod(value) {
	return PERIODS.some((period) => period.id === value);
}
function isPeriodMap(value) {
	if (!value || typeof value !== "object") return false;
	return PERIODS.every((period) => {
		const row = value[period.id];
		return !!row && typeof row.units === "string" && typeof row.other === "string";
	});
}
function loadState() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (!isCurrency(data.currency) || !isPeriod(data.base)) return null;
		if (typeof data.units !== "string" || typeof data.other !== "string") return null;
		if (typeof data.cost !== "string" || typeof data.price !== "string") return null;
		const base = defaultState();
		return {
			...base,
			currency: data.currency,
			rate: typeof data.rate === "string" ? data.rate : base.rate,
			cost: data.cost,
			price: data.price,
			base: data.base,
			linked: data.linked !== false,
			units: data.units,
			other: data.other,
			byPeriod: isPeriodMap(data.byPeriod) ? data.byPeriod : projectFields(data.units, data.other, data.base),
			saved: Array.isArray(data.saved) ? data.saved.filter(isSaved) : []
		};
	} catch {
		return null;
	}
}
function isSaved(value) {
	if (!value || typeof value !== "object") return false;
	const row = value;
	return typeof row.id === "string" && isCurrency(row.currency) && typeof row.monthlyProfit === "number" && isPeriod(row.base);
}
function Field({ label, value, onChange, suffix }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block min-w-0 rounded-card border border-line bg-surface px-5 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-base font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-2 flex min-w-0 items-end gap-3 border-b-2 border-gold pb-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				inputMode: "decimal",
				enterKeyHint: "done",
				size: 6,
				value,
				onChange: (event) => onChange(sanitizeAmount(event.target.value)),
				className: "w-0 min-w-0 flex-1 bg-transparent text-4xl font-semibold tracking-tight text-fg outline-none tabular-nums",
				placeholder: "0"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1 shrink-0 text-sm font-semibold text-gold",
				children: suffix
			})]
		})]
	});
}
function MoneyLine({ amount, currency, rate, signed = false, className }) {
	const fmt = signed ? formatSigned : formatMoney;
	const twin = otherCurrency(currency);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block tabular-nums",
			children: fmt(amount, currency)
		}), rate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 block text-xs font-medium text-muted tabular-nums",
			children: fmt(convert(amount, currency, rate), twin)
		}) : null]
	});
}
function Tip({ active, payload, currency }) {
	if (!active || !payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-lg border border-line bg-bg px-3 py-2 text-sm font-medium text-fg tabular-nums",
		children: formatSigned(Number(payload[0].value ?? 0), currency)
	});
}
function ProfitChart({ rows, currency }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-44" });
	const data = rows.map((row) => ({
		name: row.short,
		ganancia: row.profit
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-44 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				margin: {
					top: 8,
					right: 4,
					left: 4,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "name",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						},
						axisLine: false,
						tickLine: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						cursor: { fill: "var(--color-surface-2)" },
						content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, { currency })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "ganancia",
						radius: [
							8,
							8,
							4,
							4
						],
						maxBarSize: 48,
						children: data.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: row.ganancia >= 0 ? "var(--color-gold)" : "var(--color-loss)" }, row.name))
					})
				]
			})
		})
	});
}
function periodPhrase(id) {
	if (id === "day") return "del día";
	if (id === "week") return "de la semana";
	if (id === "fortnight") return "de la quincena";
	return "del mes";
}
function insight(row, currency) {
	if (row.unitMargin < 0) return "Cada unidad se vende por menos de lo que cuesta. Sube el precio o baja el coste antes de pensar en volumen.";
	if (row.unitMargin === 0) return "El precio y el coste son iguales. Los otros gastos no se cubren con las ventas.";
	if (row.units <= 0 && row.other <= 0) return "Escribe cuántas unidades esperas vender para ver la ganancia de cada periodo.";
	const extra = row.breakEvenUnits != null ? Math.max(row.units - row.breakEvenUnits, 0) : 0;
	if (row.profit < 0 && row.breakEvenUnits != null) return `Te faltan ${formatUnits(row.breakEvenUnits - row.units)} unidades ${periodPhrase(row.id)} para no perder. El equilibrio está en ${formatUnits(row.breakEvenUnits)}.`;
	if (row.breakEvenUnits != null) return `Con ${formatUnits(row.units)} unidades cubres los gastos y te sobran ${formatUnits(extra)}. Cada una deja ${formatMoney(row.unitMargin, currency)} antes de otros gastos.`;
	return "Ajusta precio, coste y unidades para ver si el negocio se sostiene.";
}
function NegocioLab() {
	const [state, setState] = (0, import_react.useState)(defaultState);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [flash, setFlash] = (0, import_react.useState)(false);
	const [savedFlash, setSavedFlash] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const stored = loadState();
		if (stored) setState(stored);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
	}, [state, ready]);
	const rate = parseAmount(state.rate);
	const results = (0, import_react.useMemo)(() => buildResults(state), [state]);
	const selected = results.find((row) => row.id === state.base) ?? results[3];
	const month = results.find((row) => row.id === "month") ?? results[3];
	const activeUnits = state.linked ? state.units : state.byPeriod[state.base].units;
	const activeOther = state.linked ? state.other : state.byPeriod[state.base].other;
	const period = periodById(state.base);
	const shifts = [
		{
			id: "low",
			label: "−30 %",
			factor: -.3
		},
		{
			id: "plan",
			label: "Tu plan",
			factor: 0
		},
		{
			id: "high",
			label: "+30 %",
			factor: .3
		}
	].map((shift) => ({
		...shift,
		row: withUnitShift(state, state.base, shift.factor)
	}));
	function patch(partial) {
		setState((current) => ({
			...current,
			...partial
		}));
	}
	function editMoney(field, value) {
		setState((current) => {
			if (field === "cost" || field === "price") return {
				...current,
				[field]: value
			};
			if (current.linked) return {
				...current,
				[field]: value
			};
			return {
				...current,
				[field]: value,
				byPeriod: {
					...current.byPeriod,
					[current.base]: {
						...current.byPeriod[current.base],
						[field]: value
					}
				}
			};
		});
	}
	function selectPeriod(next) {
		setState((current) => {
			if (next === current.base) return current;
			if (!current.linked) return {
				...current,
				base: next
			};
			const factor = DAYS[next] / DAYS[current.base];
			return {
				...current,
				base: next,
				units: formatInput(parseAmount(current.units) * factor),
				other: formatInput(parseAmount(current.other) * factor)
			};
		});
	}
	function toggleLinked() {
		setState((current) => {
			if (current.linked) return {
				...current,
				linked: false,
				byPeriod: projectFields(current.units, current.other, current.base)
			};
			const source = current.byPeriod[current.base];
			return {
				...current,
				linked: true,
				units: source.units,
				other: source.other
			};
		});
	}
	function setCurrency(next) {
		setState((current) => {
			if (next === current.currency) return current;
			const fx = parseAmount(current.rate);
			const conv = (raw) => {
				if (!(fx > 0)) return raw;
				const amount = parseAmount(raw);
				return formatInput(current.currency === "CUP" ? amount / fx : amount * fx);
			};
			const byPeriod = {};
			for (const item of PERIODS) byPeriod[item.id] = {
				units: current.byPeriod[item.id].units,
				other: conv(current.byPeriod[item.id].other)
			};
			return {
				...current,
				currency: next,
				cost: conv(current.cost),
				price: conv(current.price),
				other: conv(current.other),
				byPeriod
			};
		});
	}
	function applyPreset(id) {
		const preset = PRESETS.find((item) => item.id === id);
		if (!preset) return;
		setState((current) => ({
			...current,
			currency: preset.currency,
			cost: preset.cost,
			price: preset.price,
			base: preset.base,
			linked: true,
			units: preset.units,
			other: preset.other,
			byPeriod: projectFields(preset.units, preset.other, preset.base)
		}));
	}
	function simular() {
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		document.getElementById("comparar")?.scrollIntoView({
			behavior: reduce ? "auto" : "smooth",
			block: "start"
		});
		setFlash(true);
		window.setTimeout(() => setFlash(false), 700);
	}
	function registrar() {
		const stamp = /* @__PURE__ */ new Date();
		patch({ saved: [{
			id: crypto.randomUUID(),
			createdAt: stamp.getTime(),
			label: `Simulación ${state.saved.length + 1}`,
			currency: state.currency,
			rate: state.rate,
			cost: state.cost,
			price: state.price,
			base: state.base,
			linked: state.linked,
			units: state.units,
			other: state.other,
			byPeriod: state.linked ? projectFields(state.units, state.other, state.base) : state.byPeriod,
			monthlyProfit: month.profit
		}, ...state.saved].slice(0, 20) });
		setSavedFlash(true);
		window.setTimeout(() => setSavedFlash(false), 1400);
	}
	function restore(entry) {
		patch({
			currency: entry.currency,
			rate: entry.rate || state.rate,
			cost: entry.cost,
			price: entry.price,
			base: entry.base,
			linked: entry.linked,
			units: entry.units,
			other: entry.other,
			byPeriod: isPeriodMap(entry.byPeriod) ? entry.byPeriod : projectFields(entry.units, entry.other, entry.base)
		});
	}
	const total = state.saved.reduce((sum, entry) => {
		if (entry.currency === state.currency) return sum + entry.monthlyProfit;
		return sum + convert(entry.monthlyProfit, entry.currency, rate);
	}, 0);
	const mixParts = [
		{
			key: "coste",
			label: "Coste",
			value: Math.max(selected.cogs, 0),
			swatch: "bg-line"
		},
		{
			key: "otros",
			label: "Otros gastos",
			value: Math.max(selected.other, 0),
			swatch: "bg-muted"
		},
		{
			key: "gana",
			label: "Ganancia",
			value: Math.max(selected.profit, 0),
			swatch: "bg-gold"
		}
	];
	const mixSum = mixParts.reduce((sum, part) => sum + part.value, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full min-w-0 max-w-lg px-4 pt-6 pb-16 lg:max-w-5xl lg:px-8 lg:pt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-xs font-semibold tracking-widest text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), "CAMINO A LA LIBERTAD"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 text-4xl font-extrabold tracking-tight text-balance text-fg",
							children: "Laboratorio de negocios"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-lg leading-relaxed text-pretty text-muted",
							children: "Experimenta con precios, costes y ventas en CUP y en USD antes de arriesgar dinero real."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => applyPreset(preset.id),
								className: "rounded-full border border-line bg-surface px-3 py-2 text-sm font-semibold text-fg",
								children: preset.label
							}, preset.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 lg:grid lg:grid-cols-2 lg:items-start lg:gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid min-w-0 gap-3 lg:sticky lg:top-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex w-full min-w-0 flex-col gap-3 rounded-card border border-line bg-bg-deep px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid w-full min-w-0 grid-cols-2 gap-1 rounded-full bg-surface p-1 sm:w-auto",
									role: "group",
									"aria-label": "Moneda",
									children: ["CUP", "USD"].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setCurrency(code),
										className: "rounded-full px-4 py-2 text-sm font-semibold " + (state.currency === code ? "bg-gold text-gold-ink" : "text-muted"),
										"aria-pressed": state.currency === code,
										children: code
									}, code))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-w-0 items-center gap-2 text-sm text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0",
											children: "1 USD ="
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											inputMode: "decimal",
											value: state.rate,
											onChange: (event) => patch({ rate: sanitizeAmount(event.target.value) }),
											className: "w-20 border-b border-gold bg-transparent py-1 text-base font-semibold text-fg outline-none tabular-nums",
											"aria-label": "Tasa en CUP por cada dólar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "CUP" })
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid w-full min-w-0 grid-cols-4 gap-1 rounded-card bg-surface p-1",
									role: "group",
									"aria-label": "Periodo",
									children: PERIODS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => selectPeriod(item.id),
										className: "min-w-0 rounded-xl px-0.5 py-3 text-xs font-semibold sm:text-sm " + (state.base === item.id ? "bg-gold text-gold-ink" : "text-muted"),
										"aria-pressed": state.base === item.id,
										children: item.chip
									}, item.id))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex min-w-0 items-center justify-between gap-3 px-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "min-w-0 flex-1 text-sm leading-snug text-muted",
										children: state.linked ? `Los números son ${periodPhrase(state.base)}. Los demás periodos siguen el mismo ritmo.` : `Estás anotando ${periodPhrase(state.base)} por separado.`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "switch",
										"aria-checked": state.linked,
										"aria-label": "Mismo ritmo en todos los periodos",
										onClick: toggleLinked,
										className: "relative h-7 w-12 shrink-0 rounded-full " + (state.linked ? "bg-gold" : "bg-line"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0.5 size-6 rounded-full " + (state.linked ? "left-5 bg-gold-ink" : "left-0.5 bg-fg") })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Unidades que esperas vender",
								value: activeUnits,
								onChange: (value) => editMoney("units", value),
								suffix: period.short
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `Coste por unidad (${state.currency})`,
								value: state.cost,
								onChange: (value) => editMoney("cost", value),
								suffix: state.currency
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `Precio de venta por unidad (${state.currency})`,
								value: state.price,
								onChange: (value) => editMoney("price", value),
								suffix: state.currency
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: `Otros gastos totales (${state.currency})`,
								value: activeOther,
								onChange: (value) => editMoney("other", value),
								suffix: period.short
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: simular,
								className: "flex w-full min-w-0 items-center justify-center gap-2 rounded-xl bg-gold px-4 py-4 text-lg font-bold text-gold-ink",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, {
									className: "size-5",
									"aria-hidden": "true"
								}), "Simular el negocio"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: registrar,
								className: "w-full min-w-0 rounded-card border border-line bg-surface px-4 py-4 text-center text-base font-semibold leading-snug text-balance text-fg",
								children: savedFlash ? "Guardado en activos" : `Registrar ${formatSigned(month.profit, state.currency)}/mes simulado en activos`
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "comparar",
						className: "mt-8 scroll-mt-6 grid min-w-0 gap-3 lg:mt-0 " + (flash ? "rounded-card ring-2 ring-gold" : ""),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "px-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-bold",
									children: "Comparar periodos"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										"Día, semana, quincena y mes, en ",
										state.currency,
										" y en ",
										otherCurrency(state.currency),
										"."
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2",
								children: results.map((row) => {
									const positive = row.profit >= 0;
									const active = row.id === state.base;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => selectPeriod(row.id),
										className: "rounded-card border px-3 py-3 text-left " + (active ? "border-gold bg-surface-2" : "border-line bg-surface"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-semibold tracking-wide text-muted uppercase",
												children: row.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 block text-xl font-bold tabular-nums " + (positive ? "text-gain" : "text-loss"),
												children: formatSigned(row.profit, state.currency)
											}),
											rate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 block text-xs text-muted tabular-nums",
												children: formatSigned(convert(row.profit, state.currency, rate), otherCurrency(state.currency))
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-2 block text-xs text-muted tabular-nums",
												children: [formatUnits(row.units), " uds"]
											})
										]
									}, row.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-card border border-line bg-surface px-5 py-5",
								"aria-live": "polite",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold tracking-wide text-gold uppercase",
										children: selected.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyLine, {
										amount: selected.profit,
										currency: state.currency,
										rate,
										signed: true,
										className: "mt-2 text-4xl font-extrabold " + (selected.profit >= 0 ? "text-gain" : "text-loss")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-pretty text-muted",
										children: insight(selected, state.currency)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
										className: "mt-5 grid gap-3 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Ingresos",
												value: formatMoney(selected.revenue, state.currency)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Coste de unidades",
												value: formatMoney(-selected.cogs, state.currency)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Otros gastos",
												value: formatMoney(-selected.other, state.currency)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Ganancia",
												value: formatSigned(selected.profit, state.currency),
												strong: true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Margen",
												value: formatPercent(selected.margin)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Por unidad, antes de otros",
												value: formatSigned(selected.unitMargin, state.currency)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
												label: "Unidades para equilibrar",
												value: selected.breakEvenUnits == null ? "No alcanza" : formatUnits(selected.breakEvenUnits)
											})
										]
									}),
									mixSum > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex h-3 overflow-hidden rounded-full bg-bg",
											children: mixParts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: part.swatch,
												style: { width: `${part.value / mixSum * 100}%` }
											}, part.key))
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted",
											children: mixParts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full " + part.swatch }), part.label]
											}, part.key))
										})]
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-card border border-line bg-surface px-5 py-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-bold",
										children: "Si vendes más o menos"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted",
										children: [
											"Los otros gastos se quedan quietos. Solo cambian las unidades de ",
											period.label.toLowerCase(),
											"."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 grid grid-cols-3 gap-2",
										children: shifts.map((shift) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-bg px-2 py-3 text-center",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-semibold text-muted",
													children: shift.label
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm font-bold tabular-nums " + (shift.row.profit >= 0 ? "text-gain" : "text-loss"),
													children: formatSigned(shift.row.profit, state.currency)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "mt-1 text-xs text-muted tabular-nums",
													children: [formatUnits(shift.row.units), " uds"]
												})
											]
										}, shift.id))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-card border border-line bg-surface px-4 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "px-1 text-base font-bold",
									children: "Ganancia según el periodo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfitChart, {
									rows: results,
									currency: state.currency
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 rounded-card border border-line bg-surface px-5 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold",
							children: "Activos simulados"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "La suma mensual de lo que guardaste. No es dinero real."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-right text-lg font-bold tabular-nums " + (total >= 0 ? "text-gain" : "text-loss"),
							children: [formatSigned(total, state.currency), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs font-medium text-muted",
								children: "al mes"
							})]
						})]
					}), state.saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted",
						children: "Todavía no hay simulaciones guardadas. Cuando un número te convenza, regístralo arriba."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2",
						children: state.saved.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2 border-b border-line py-3 last:border-b-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => restore(entry),
									className: "min-w-0 flex-1 text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate font-semibold",
										children: entry.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-0.5 block text-xs text-muted",
										children: [
											new Date(entry.createdAt).toLocaleDateString("es", {
												day: "numeric",
												month: "short"
											}),
											" · ",
											periodById(entry.base).label,
											" · ",
											entry.currency
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-sm font-bold tabular-nums " + (entry.monthlyProfit >= 0 ? "text-gain" : "text-loss"),
									children: formatSigned(entry.monthlyProfit, entry.currency)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Quitar ${entry.label}`,
									onClick: () => patch({ saved: state.saved.filter((item) => item.id !== entry.id) }),
									className: "grid size-11 shrink-0 place-items-center rounded-full text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})
							]
						}, entry.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-center text-xs leading-relaxed text-muted",
					children: "Mes de 30 días, quincena de 15 y semana de 7. Los CUP se redondean al peso. La tasa la pones tú: no es un cambio oficial."
				})
			]
		})
	});
}
function Row({ label, value, strong = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-4 " + (strong ? "border-t border-line pt-3 text-base" : ""),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "tabular-nums " + (strong ? "font-bold text-fg" : "font-semibold text-fg"),
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NegocioLab, {});
}
//#endregion
export { Home as component };
